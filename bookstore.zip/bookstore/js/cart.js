function increase(i){
    var price = document.getElementsByName("single")[i].innerHTML.substring(1);
    price = parseInt(price);
    var num = document.getElementsByClassName("cart_quantity_input")[i].value;
    num = parseInt(num) + 1;
    document.getElementsByClassName("cart_quantity_input")[i].value = num;
    var total = num * price;
    total = total.toString();
    total = "$"+total;
    document.getElementsByClassName("cart_total_price")[i].innerHTML = total; 
}

function decrease(i){
    var price = document.getElementsByName("single")[i].innerHTML.substring(1);
    price = parseInt(price);
    var num = document.getElementsByClassName("cart_quantity_input")[i].value;
    num = parseInt(num) - 1;
    if(num == -1)
        return;
    document.getElementsByClassName("cart_quantity_input")[i].value = num;
    var total = num * price;
    total = total.toString();
    total = "$"+total;
    document.getElementsByClassName("cart_total_price")[i].innerHTML = total; 
}