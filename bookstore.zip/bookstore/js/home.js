function wrapper(x){
    var chil1 = document.createElement("div");
        chil1.className = "features_items";
        chil1.setAttribute('name','deWhenSearch');
        var chil2 = document.createElement("div");
        chil2.className = "col-sm-4";
        var chil3 = document.createElement("div");
        chil3.className = "product-image-wrapper";
        var chil4 = document.createElement("div");
        chil4.className = "single-products";
        var chil5 = document.createElement("div");
        chil5.className = "productinfo text-center";
        var ima = document.createElement("img");
        ima.src = "images/home/book.jpeg";
        ima.alt = "";
        var h = document.createElement("h2");
        h.innerText = "$56";
        var p = document.createElement("p");
        p.innerHTML = x;
        chil5.appendChild(ima);
        chil5.appendChild(h);
        chil5.appendChild(p);
        chil4.appendChild(chil5);  
        var chil6 = document.createElement("div");
        chil6.className = "product-overlay";
        var chil7 = document.createElement("div");
        chil7.className = "overlay-content";
        var a1 = document.createElement("a");
        a1.href = "#";
        a1.className = "btn btn-default add-to-cart";
        a1.innerHTML = "Add to cart";
        var i1 = document.createElement("i");
        i1.className = "fa fa-shopping-cart";
        var a2 = document.createElement("a");
        a2.href = "detail.html";
        a2.className = "btn btn-default add-to-cart";
        a2.innerHTML = "Know more";
        var i2 = document.createElement("i");
        i2.className = "fa fa-shopping-cart";
        var h2 = document.createElement("h2");
        h.innerText = "$56";
        var p2 = document.createElement("p");
        p.innerHTML = x;
        a1.appendChild(i1);
        a2.appendChild(i2);
        chil7.appendChild(h2);
        chil7.appendChild(p2);
        chil7.appendChild(a1);
        chil7.appendChild(a2);
        chil6.appendChild(chil7);
        chil4.appendChild(chil6);
        chil3.appendChild(chil4);
        chil2.appendChild(chil3);
        chil1.appendChild(chil2);
        document.getElementById("changeWhenSearch").appendChild(chil1);
}

function wa(){
    return(<div class="col-sm-4"> 
    <div class="product-image-wrapper">
        <div class="single-products">
                <div class="productinfo text-center">
                    <img src="images/home/book.jpeg" alt="" />
                    <h2>$56</h2>
                    <p>The Lord of the Rings</p>
                </div>
                <div class="product-overlay">
                    <div class="overlay-content">
                        <h2>$56</h2>
                        <p>The Lord of the Rings</p>
                        <a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                        <a href="detail.html" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Know more</a>
                    </div>
                </div>
                <img src="images/home/new.png" class="new" alt="" />
        </div>
        <div class="choose">
            <ul class="nav nav-pills nav-justified">
                <li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
            </ul>
        </div>
    </div>
</div>);
}



function search(e,id)
{
    if(e.keyCode != "13")
       return;
    var sear = id.value;
    if(sear != ""){
        var sl = document.getElementById("slider");
        sl.remove();
        var tl = document.getElementsByName("deWhenSearch");
        document.getElementById("changeWhenSearch").removeChild(tl[0]);
        wrapper("the Lord of the Rings");
    }
}

