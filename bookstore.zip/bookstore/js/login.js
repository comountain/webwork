function check(){
    if(document.getElementById("getusername").value=="comountain" && document.getElementById("getpassword").value=="973717287thy")
        return "home.html";
    else{
        if(document.getElementById("getusername").value=="" || document.getElementById("getpassword").value=="")
            alert("内容不能为空");
        else if(document.getElementById("getusername").value!="comountain")
            alert("用户名错误");
        else if(document.getElementById("getpassword").value!="973717287thy")
            alert("密码错误");
        return "login.html";
    }
}