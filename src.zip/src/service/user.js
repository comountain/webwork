
import {history} from '../utils/History.js';


export const login = (name,word) => {
        if(name === 'sjtuthy1210' && word === '973717287thy')
        {
            history.push("/home");
        }
}