import React from "react";
import Pic1 from '../images/home/book.jpeg';
import Pic2 from '../images/home/book4.jpeg';
import Pic3 from '../images/home/book3.jpeg';



var books = [{'name':'The Lord of the Rings','price':'70','image':Pic1,'author':'J.R.R.Tolkien','type':'novel'}] 
var dream = [{'name':"Dream of the Red Chamber",'price':'25','image':Pic2, 'author':'Cao Xueqin','type':'novel'}]
var prince = [{'name':'The Little Prince','price':'15','image':Pic3,'author':'Antoine de Saint-Exupéry','type':'novel'}]
var search = [{'The Lord of the Rings':books,'Dream of the Red Chamber':dream,'The Little Prince':prince,
               'Lord':books,'lord':books,'Rings':books,'rings':books,'Dream':dream,'dream':dream,'Little':prince, 'little':prince,
               'Red':dream,'red':dream,'Chamber':dream,'chamber':dream,'Prince':prince,'prince':prince}]
var dataSend = []

function getRandomInt(max, min = 0) {
    return Math.floor(Math.random() * (max - min + 1)) + min; // eslint-disable-line no-mixed-operators
}

dataSend.length = 120;
for(var i = 0; i < 120; i++)
{
    let tmp = getRandomInt(2);
    if(tmp === 0)
        dataSend[i] = books[0];
    if(tmp === 1)
        dataSend[i] = dream[0];
    if(tmp === 2)
        dataSend[i] = prince[0]; 
}

export const getbooks = (data,callback) =>{
    if(data == null)
        return callback(dataSend);

}

export const getbook = (name) => {
    if(name === '')
        return(dataSend);
    var result = search[0][name];
    return result;
}