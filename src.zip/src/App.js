
import React from 'react';
import BasicRoute from './Router';


class App extends React.Component{
  render(){
    return(
      <BasicRoute />
    );
  }
}

export default App;
