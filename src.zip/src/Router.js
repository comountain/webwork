import React from "react";
import { Router, Route, Switch, Redirect} from 'react-router-dom';
import BookView from "./view/BookView";
import HomeView from "./view/HomeView";
import LoginView from "./view/LoginView";
import { history } from "./utils/History";

class BasicRoute extends React.Component{
    constructor(props) {
        super(props);
        history.listen((location, action) => {
            console.log(location,action);
        });
    }
    render(){
        return(
            <Router history={history}>
                <Switch>
                    <Route exact path="/home"> <HomeView /> </Route>
                    <Route exact path="/"> <LoginView /> </Route>
                    <Route exact path="/bookDetails"> <BookView /> </Route>
                    <Redirect from="/*" to="/" />
                </Switch>

            </Router>
        )
    }

}

export default BasicRoute