import React from "react";
import Panel from './Panel.js'
import '../css/main.css'


class HomeBar extends React.Component{
    state = {
        collapsed: false,
    };

    onCollapse = collapsed => {
        if(collapsed){

        }
        console.log(collapsed);
        this.setState({ collapsed });
    };

    render(){
        return(
                <div className="col-sm-3" style={{position: 'fixed',marginLeft:-100, marginTop: 150, width: 300}}>
                      <div className="left-sidebar">
                        <h2 style={{color: 'rgb(2,17,17)'}}>
                               Top Features
                        </h2>
                        <div className="panel-group category-products" id="accordian">
                            <Panel name="popular"/>
                            <Panel name="promotion"/>
                            <Panel name="recent"/>
                        </div>
                        <h2 style={{color: 'rgb(2,17,17)'}}>
                            CATEGORY
                        </h2>
                        <div class="brands-name">
                         <ul class="nav nav-pills nav-stacked">
                             <li><a href="#"> <span class="pull-right"></span>education</a></li>
                             <li><a href="#"> <span class="pull-right"></span>novel</a></li>
                             <li><a href="#"> <span class="pull-right"></span>literature and art</a></li>
                             <li><a href="#"> <span class="pull-right"></span>social science</a></li>
                             <li><a href="#"> <span class="pull-right"></span>history</a></li>
                             <li><a href="#"> <span class="pull-right"></span>comic</a></li>
                             <li><a href="#"> <span class="pull-right"></span>science</a></li>
                             <li><a href="#"> <span class="pull-right"></span>reference books</a></li>
                         </ul>
                        </div>
                    </div>
                </div>
        );
    }
}

export default HomeBar