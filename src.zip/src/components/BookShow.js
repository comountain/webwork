import React from "react";
import Book from "./Book";
import {getbooks} from '../service/search.js';
import { List } from "antd";
import emitter from '../events';
import '../css/main.css';
import '../css/responsive.css';
import 'bootstrap/dist/css/bootstrap.min.css';



class BookShow extends React.Component{

    constructor(props){
        super(props);
        this.state = {books:[]};
    }

    componentDidMount(){
        const callback = (data1) => {
            this.setState({books:data1})
        };
        getbooks(null,callback);
        this.eventEmitter = emitter.addListener("callMe",(msg)=>{
          this.setState({
             books: msg
          })
      });
    }
    

    render() {
      
        return (
                        <List
                     
                            grid={{gutter: 0, column: 0}}
                            dataSource={this.state.books}
                            /*pagination={{
                                onChange: page => {
                                    console.log(page);
                                },
                                pageSize: 6,
                            }}*/
                            renderItem={item => (
                                <List.Item>
                                    <Book info={item} />
                                </List.Item>
                            )}
                        />
                       
        );
    }
}

export default BookShow



