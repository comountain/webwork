import React from 'react';
import { Carousel } from 'antd';
import '../css/main.css'
import '../css/responsive.css'


  
class BookCarousel extends React.Component{
  render(){
      return(null);

  }
}

export default BookCarousel