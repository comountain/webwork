import React from "react";
import '../css/main.css';
import '../css/responsive.css';
import HeadTop from "./HeadTop";
import HeadMid from "./HeadMid";

class Head extends React.Component{
    render(){
        return(
            <header id="header" style={{position: "fixed", marginLeft: -110, zIndex: 10000, width: 1700, backgroundColor:'white'}}>
                <HeadTop mail="youshi@bielaizhaowo.com" />
                <HeadMid />
            </header>
        );
    }
}

export default Head