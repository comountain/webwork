import React from "react";
import '../css/main.css';
import '../css/responsive.css'
import Pic1 from '../images/popular.png'
import Pic2 from '../images/recent.png'
import Pic3 from '../images/promotion.png'


function Imagee(props){
    switch(props.name){
        case 'popular':
            return(<img src={Pic1} width = "25px" height = "25px" alt=""></img>);
        case 'recent':
            return(<img src={Pic2} width = "25px" height = "25px" alt=""></img>);
        case 'promotion':
            return(<img src={Pic3} width = "25px" height = "25px" alt=""></img>);
        default:
            return null;
    }
}

class Panel extends React.Component{
    render(){
        return(
            <div className="panel panel-default">
                <div className="panel-heading">
                    <h4 className="panel-title">
                        <a>
                            <Imagee name={this.props.name} />
                                <span className="badge pull-right"><i className="fa fa-plus"></i></span>
                                {this.props.name}
                        </a>
                    </h4>
                </div>
            </div>
        )
    }
}

export default Panel