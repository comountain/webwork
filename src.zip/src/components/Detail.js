import React from "react";
import '../css/main.css';
import '../css/responsive.css';

class Detail extends React.Component{
    render(){
        return(
           <div className="category-tab shop-details-tab">
                    <div className="col-sm-12">
                        <ul className="nav nav-tabs">
                            <li><a href="#" data-toggle="tab">Details</a></li>
                            <li className="active" style={{backgroundColor: 'aqua'}}><a href="#reviews" data-toggle="tab" style={{backgroundColor: 'rgb(0, 174, 255)'}}>Reviews (5)</a></li>
                        </ul>
                    </div> 
                    <div className="tab-content">
                        <div className="tab-pane fade active in" id="reviews" >
								<div className="col-sm-12">
									<ul>
										<li><a href=""><i className="fa fa-user"></i>EUGEN</a></li>
										<li><a href=""><i className="fa fa-clock-o"></i>12:41 PM</a></li>
										<li><a href=""><i className="fa fa-calendar-o"></i>31 DEC 2014</a></li>
									</ul>
									<p></p>
									<p><b>Write Your Review</b></p>
									
									<form action="#">
										<span>
											<input type="text" placeholder="Your Name"/>
											<input type="email" placeholder="Email Address"/>
										</span>
										<textarea name="" ></textarea>
										<b>Rating: </b>
										<button type="button" className="btn btn-default pull-right" style={{backgroundColor: 'rgb(0, 174, 255)'}}>
											Submit
										</button>
									</form>
								</div>
                        </div>
                </div> 
            </div>
        );
    }
}

export default Detail