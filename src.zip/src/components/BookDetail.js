import React from "react";
import { history } from "../utils/History"; 
import { Button } from "antd";
import '../css/main.css';
import '../css/responsive.css';
import Rate from "../images/product-details/rate5.png"

class BookDetail extends React.Component{
    render(){
        const back = () =>{
            history.goBack();
        }

        const {info} = this.props;
        if(info == null){
            return null;
        }
        return(
            <div className="product-details">
                <Button onClick={back} className="btn btn-default add-to-cart" style={{marginLeft: 320}}><i className="fa fa-shopping-cart"></i>return</Button>
                    <div className="col-sm-5">
                        <div className="view-product">
                            <img src={info.image} alt="" />
                        </div>
                    </div>
                    <div className="col-sm-7">
                        <div className="product-information">
                            <h2>
                                {info.name}
                            </h2>
                            <img src={Rate} alt="" width="125px" height="25px" />
                            <span>
                                <span style={{color: 'rgba(35, 169, 202, 0.904)'}}>￥ {info.price}</span>
                                
                                <button type="button" onclick="" className="btn btn-fefault cart"  style={{backgroundColor: 'rgb(0, 174, 255)'}}>
                                    <i className="fa fa-shopping-cart"></i>
                                    Buy now
                                </button>
                                <button type="button" className="btn btn-fefault cart"  style={{backgroundColor: 'rgb(0, 174, 255)'}}>
                                    <i className="fa fa-shopping-cart"></i>
                                    Add to cart
                                </button>
                            </span>
                            <p><b>Author:</b> {info.author}</p>
                            <p><b>Type:</b> {info.type}</p>
                        </div>
                    </div>
                </div>
        );
    }
}

export default BookDetail