import React from "react";
import { Link } from "react-router-dom";
import { Menu, Dropdown, Button } from 'antd';
import { DownOutlined } from '@ant-design/icons'
import '../css/main.css';
import '../css/responsive.css';
import Pic from '../images/newlogo.png'
import SearchBar from "./SearchBar";
import { setMaxListeners } from "events";

class HeadMid extends React.Component{
    render(){
    const menu = (
            <Menu>
              <Menu.Item>
                <h4>sjtuthy1210</h4>
              </Menu.Item>
              <br />
              <Menu.Item>
                <Link><h6>Shopping Cart</h6></Link>
              </Menu.Item>
              <br />
              <Menu.Item>
                 <Link>settings</Link>
              </Menu.Item>
              <br />
              <Menu.Item>
                 <Link>log out</Link>
              </Menu.Item>
            </Menu>
          );
    
    return(
    <div className="header-middle">
        <div className="container">
            <div className="row">
                <div className="col-sm-4">
                    <div className="logo pull-left">
                        <Link to="/home"><img src={Pic} width = "170px" height = "50px" alt=""></img></Link>
                    </div>
                </div>
                <div className="col-sm-8">
                    <div className="shop-menu pull-right">
                        <ul className="nav navbar-nav">
                            <li><Dropdown overlay={menu} arrow={true} 
                                overlayStyle={{marginTop: 100, marginLeft: 1150, zIndex: 100000, 
                                    backgroundColor: "#f5f8fa", width: 200, position: "fixed"}} 
                                placement="bottomLeft"
                                >
                                <Link className="ant-dropdown-link" onClick={() => {}}>
                                     Account<DownOutlined /></Link></Dropdown></li>
                            <li><Link><i className="fa fa-shopping-cart"></i> Cart</Link></li>
                            <li><Link to="/"><i className="fa fa-lock"></i> Login</Link></li>
                        </ul>
                    </div>
                </div>
                <SearchBar />
            </div>
        </div>
    </div>
    );
    }
}

export default HeadMid