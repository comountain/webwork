import React from "react";
import {Input,Space} from 'antd';
import '../css/main.css';
import '../css/responsive.css';
import { getbook } from "../service/search.js";
import emitter from '../events';

const {Search} = Input
const onSearch = value => {
    console.log(value);
    var info = getbook(value);
    emitter.emit("callMe",info);
}

class SearchBar extends React.Component{
    render(){
        return(
            <Space direction="vertical">
                <Search enterbutton placeholder="search what you want" onSearch={onSearch}  />
            </Space>
        );
    }
}

export default SearchBar