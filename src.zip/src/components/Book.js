import React from "react";
import { Link } from "react-router-dom";
import '../css/main.css';
import '../css/responsive.css';
import 'bootstrap/dist/css/bootstrap.min.css';



class Book extends React.Component{
    render(){
        const {info} = this.props;
        return(
        <div className="col-sm-4"> 
            <div className="product-image-wrapper">
                <div className="single-products">
                        <div className="productinfo text-center">
                            <img alt="" src={info.image} />
                            <h2>¥ {info.price}</h2>
                            <p>{info.name}</p>
                        </div>
                        <div className="product-overlay">
                            <div className="overlay-content">
                                <h2>¥ {info.price}</h2>
                                <p>{info.name} </p>
                                <Link className="btn btn-default add-to-cart"><i className="fa fa-shopping-cart"></i>Add to cart</Link>
                                <br />
                                <Link to={{
                                pathname: '/bookDetails',
                                search: '?id=' + info.name}} className="btn btn-default add-to-cart"><i className="fa fa-shopping-cart"></i>Know more</Link>
                            </div>
                        </div>
                </div>
                <div className="choose">
                    <ul className="nav nav-pills nav-justified">
                        <li><a href="#"><i className="fa fa-plus-square"></i>Add to wishlist</a></li>
                    </ul>
                </div>
            </div>
        </div>
        );
    }
}

export default Book