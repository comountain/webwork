import React from 'react';
import HomeBar from '../components/HomeBar.js';
import Head from '../components/Head.js';
import BookCarousel from '../components/BookCarousel.js';
import  BookShow  from '../components/BookShow.js';
import {withRouter} from 'react-router-dom'
import { BackTop } from 'antd';
import '../css/main.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/responsive.css';


class HomeView extends React.Component {
    render(){
        return(
        <body>
         <Head />
         <BookCarousel />
         <section>
             <div className="container">
                <div className="row">
                    <HomeBar />
                    <div class="col-sm-9 padding-right" style={{marginLeft: 350, marginTop:170}}>
                        <div class="features_items">  
                            <BookShow/>                                             
                        </div>
                    </div>        
                </div>
             </div>
             <div><BackTop style={{marginLeft: 1500, color: 'blue', width: 40}} visibilityHeight='600'/></div>
         </section>
        
        </body>
    );
  }
}

export default withRouter(HomeView)