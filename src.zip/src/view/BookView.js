import React from 'react';
import HomeBar from '../components/HomeBar.js';
import Head from '../components/Head.js';
import BookDetail from '../components/BookDetail';
import {withRouter} from 'react-router-dom';
import { getbook } from '../service/search.js';
import Detail from '../components/Detail.js';
import '../css/main.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/responsive.css';

class BookView extends React.Component {
    constructor(props){
        super(props);
        this.state = {books:null};
    }
    componentDidMount(){
        window.scrollTo(0,0);
        const query = this.props.location.search;
        const arr = query.split('&');
        const bookId = arr[0].substr(4);
        var inf = getbook(bookId)[0]
        this.setState({
            books:inf
        })
    }
    render(){
        return(
        <body>
         <Head />
         <section>
             <div className="container">
                <div className="row">
                    <HomeBar />
                    <div class="col-sm-9 padding-right" style={{marginLeft: 350, marginTop:170}}>
                        <div class="features_items">  
                            <BookDetail info={this.state.books}/>
                            <Detail />
                        </div>
                    </div>        
                </div>
             </div>
         </section>
        </body>
    );
  }
}

export default withRouter(BookView)